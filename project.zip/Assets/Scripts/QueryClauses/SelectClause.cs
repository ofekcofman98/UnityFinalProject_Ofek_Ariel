    using System.Collections;
    using System.Collections.Generic;
    using System.Linq;
    using UnityEngine;

    public class SelectClause : IQueryClause
    {
        public string DisplayName => QueryConstants.Select;
        public List<Column> Columns { get; set; }
        public string SelectPart { get; private set; } = QueryConstants.Empty;
        public bool isClicked { get; private set; } = false;
        public bool isAvailable { get; set; } = true;

        public SelectClause()
        {
            Columns = new List<Column>();
        }
        
        // public void Toggle()
        // {
        //     isClicked = !isClicked;

        //     if (!isClicked)
        //     {
        //         ClearColumns();
        //     }

        //     UpdateString();
        //     // onSelectChanged?.Invoke();
        // }

        public void Activate()
        {
            isClicked = true;
        }

        public void Deactivate()
        {
            if (isClicked)
            {
                Reset();
            }
            else 
            {
                isClicked = false;
            }
        }

        public void AddColumn(Column i_ColumnToAdd)
        {
            if (!Columns.Contains(i_ColumnToAdd))
            {
                Columns.Add(i_ColumnToAdd);
                UpdateString();
            }
        }
        public void RemoveColumn(Column i_ColumnToRemove)
        {
            if (Columns.Remove(i_ColumnToRemove))
            {
                Columns.Remove(i_ColumnToRemove);
                UpdateString();
            }
        }

        public void ClearColumns()
        {
            Columns.Clear();
            UpdateString();
        }
        
        public void UpdateString()
        {
            if (isClicked)
            {
                SelectPart = QueryConstants.Select;
                if (Columns.Count > 0)
                {
                    SelectPart += " " + string.Join(QueryConstants.Comma, Columns.Select(col => col.Name));
                }
            }
            else
            {
                SelectPart = QueryConstants.Empty;
            }
        }

        public string ToSQL()
        {
            return SelectPart;
        }

        public string ToSupabase()
        {
            return Columns.Count > 0 ? string.Join(QueryConstants.Comma , Columns.Select(col => col.Name)) : "*";
        }

        public bool IsEmpty()
        {
            return Columns.Count == 0;
        }

        public void OnQueryUpdated(Query query)
        {
            if (query.fromClause.GetTable() == null)
            {
                ClearColumns(); 
                UpdateString();
            }

        }

        public List<object> GetOrderedElements()
        {
            List<object> elements = new List<object>();

            if (isClicked)
            {
                elements.Add(this); // SELECT clause first
                elements.AddRange(Columns); // Then all selected columns
            }

            return elements;
        }


    public void Reset()
    {
        isClicked = false; // CHECK IT 
        SelectPart = QueryConstants.Select;
        ClearColumns();
    }
}
