using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class QueryData
{
    public List<string> SelectColumns;
    public List<string> FromTables;
}
