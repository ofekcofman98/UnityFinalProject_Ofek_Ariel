using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SceneNames
{
    public const string k_MainScene = "MainScene";
    public const string k_MobileClientScene = "MobileClientScene";
}
